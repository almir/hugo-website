::: Quake-style Terminal for Windows :::

This is not entirely my work, I just made the installer, configured the look of console window and
made the AutoIt script that uses F12 key to invoke the Console v2 application.
The AutoIt script also uses library found at http://www.autoitscript.com/forum/index.php?showtopic=90492
that allows using the F12 key, which the regular AutoIt HotKeySet() function doesn't.
The original instructions on how to make all this were found at
http://www.instructables.com/id/%22Drop-Down%22%2c-Quake-style-command-prompt-for-Window/

Applications used in this project are:
Console v2: http://sourceforge.net/projects/console/
AutoIt: http://www.autoitscript.com/autoit3/

Only screen resolutions that I could test on my machines are included.
If you want to change console size you can easily do it by editing console.xml file (search
for values rows and columns at the beginning).

::Installation::

Run setup.exe (Run as Administrator) for installation or uninstallation of Quake-style Terminal for Windows.

::Shortcuts::

Settings = Ctrl+S
Help = F1
Exit Console = Alt+F4
New Tab = Ctrl+T
Next Tab = Shift+Right
Previous Tab = Shift+Left
Close Tab = Ctrl+W
Rename Tab = Ctrl+R
Copy Selection = Ctrl+Insert
Clear Selection = Ctrl+Delete
Paste = Shift+Insert
Dump screen buffer = Ctrl+Shift+F1

::Other files::

pathman.exe is a Windows Server 2003 Resource Kit tool that will add or remove components
from the System or User path.

::Conclusion::

Thanks to the author of YaKuake, an application that was my main inspiration for this project.

Enjoy! :)

Almir Dzinovic <almirdzin@gmail.com>